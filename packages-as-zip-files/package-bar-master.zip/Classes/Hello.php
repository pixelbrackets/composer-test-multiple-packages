<?php
namespace Acme\PackageBar;

class Hello
{
	public static function world()
	{
		return 'Hello Bar World!';
	}
}
