<?php
namespace Acme\PackageFoo;

class Hello
{
	public static function world()
	{
		return 'Hello Foo World!';
	}
}
